Here are all the films of Marathon Infinity on Total Carnage done using Aleph One 1.7 / 1.8

Given that Marathon Infinity is probably the easiest of the 3 games, I opted to make things more 
challenging for myself by trying to go for no damage/hit runs for as many maps as possible

If we exclude the Electric Sheep and the secret MP maps, there are total of 28 maps in the game and 
I have managed to beat 26 of them with no hits:
- Ne Cede Malis
- Rise Robot Rise
- Poor Yorick
- Confound Delivery
- Where Are Monsters In Dreams	(speed film and took secret exit to Aie Mak Sicur)
- Acme Station
- Post Naval Trauma		(the slight goo damage is nigh unavoidable, but otherwise no hits)
- Where Some Rarely Go
- Thing What Kicks
- Whatever You Please
- Naw Man He's Close
- Foe Hammer
- Eat The Path			(unavoidable lava damage at start, but otherwise mild difficulty)
- By Committee
- One Thousand Thousand Slimy Things	(self damage due to AR jumping, but otherwise no hit)
- Converted Church in Venice Italy	(lot of mandatory lava. You'll barely make it with no hits)
- Son of Grendel		(speed film and getting enemies frozen)
- Strange Aeons
- Bagged Again
- YTYBT				(speed film)
- Aye Mak Sicur	 		(speed film)
- Aie Mak Sicur			(speed film)
- Carroll Street Station	(speed film)
- You're Wormfood Dude		(speed film)
- Vidmaster challenge 2: IIHARL	(speed film)
- Vidmaster challenge 3: YTYBT	(speed film)


And following map with no charging:
- Hang Brain			(even a no charging run was challenging due to RNG factor at start)

Only 1 map I haven't beaten with no hits or even no charging
- Vidmaster challenge 1: Try Again	(too hard. No charging is probably doable)


Notes/tips about the maps:


01 Ne Cede Malis: Easy map with somewhat similar gameplay to Arrival from M1. The hardest part when 
doing the no damage run is to fight the compilers in the sewer tanks. But you can cheese them, which 
is boring, but it works.


02 Rise Robot Rise: Easy map. Plenty of Enforcers, but many of them get killed by our ally Phfor 
Hunters.


03 Poor Yorick: Easy map. Troopers are introduced here, but here they are easy to deal with the 
magnums due to long range engagements. Just keep your distance. Also don't forget the secret to the 
2x can + SMG and also the secret exit to Two for the Price of One.


04 Confound Delivery: Very easy map. Bobs are your primary enemies here, but most of them get rekt 
by our Pfhor allies.


05 Where Are Monsters In Dreams: Very easy. The hardest part is getting to the SPNKR. Otherwise, 
just avoid the cloaked defenders and rocket jump to the terminal that takes you to Aie Mak Sicur.


07 Acme Station: Here comes the first real tough map of Infinity. As far as I am aware, there are 
two main strategies to beat the map. The first strategy is rush to the south and hit the switches 
to grab the SMG and open the 2x charger.

The other strategy is to skip going to the SMG altogether and instead rely on herding and infighting 
to get through the map. I found more success using this strategy and I was able to do 3 films with 
fists only and no damage. That isn't to say this strategy is easy and most of your attempts WILL 
fail for one reason or another. That said, I found some strategies that can help improve your 
chances of success. I have created a detailed guide for this.


08 Post Naval Trauma: Easy/medium-ish difficulty. The hardest part is getting to the oxygen and 
health charger. Especially dealing with 2 Hunters + occasionally an Enforcer in the small oxygen 
room. For that, I make sure to grab some fusion ammo before going there. Once you get it, you should 
be able to survive without much issue.


09 Where Some Rarely Go: Easy map. Though if doing a no damage run, you need to be especially be 
careful about those cloaked compilers with super fast projectiles.


10 Thing What Kicks: Easy map. Juggernauts roaming around the outer perimeter are annoying, but 
otherwise, not much resistance here. Just fighters and drones.


12 Whatever You Please: Just a puzzle/platforming map. So nothing much of note to write here.


13 Naw Man He's Close: Easy map. Though getting a no damage run was quite tough. It's mostly about 
memorizing the spawns of enemies, especially VacBobs. Thankfully plenty of ammo here and VacBobs die 
to a single AR grenade.


14 Foe Hammer: Easy map. Another hard one to get a no damage run on. While most of the enemies are 
just Hunters and Compilers, there isn't much ammo at all. So you need to get your fists dirty here. 


15 Hang Brain: The 2nd and the last hard map of Infinity. The start is really nasty. My strategy is 
wake up the hunters and then wait in the first switch room until the hunters retreat to the curved 
stairs room. Then immediately dash towards the next switches, making sure to grab AR + ammo. Pray 
you don't loose much health and make your way to the bottom floor as soon as you can. There you get 
the rest of weapons and the 3x cannister and then hold your ground against the teleporting troopers. 
Don't go downstair to pick up the SMG though as more troopers will spawn to surround you. Instead, 
safely hit the switches with the AR grenades. After all 7 switches are hit, make your way to the top 
floor and kill the compilers before jumping down to the exit.


17 Eat The Path: Another puzzle/platforming map. The starting lava damage is unavoidable, but I did 
go for a no damage run after that for the main route. Not too hard to do a no damage run and the 
only issue are those cloaked compilers.


18 By Committee: Easy map. Of course I couldn't bother to deal with the flame cyborg and the 
underground jail area in my no damage run.


19 One Thousand Thousand Slimey Things: Easy map. Only Bobs and compilers are the enemies and there 
are plenty of good secrets. Make sure to not miss the super secret which


20 Converted Church in Venice Italy: Easy map. Just make sure to press the secret switch at the 
start, so you don't have to do switch hunting. Combat is just against Bobs and you have 2x charger 
available. Getting a no damage run is impossible due to all of the mandatory lava traversal. Infact, 
I consider the no charging run of this map to the equivalent of getting a no damage run for other 
maps, since you need to take no hit and also hit the lava rising switch with the fusion and take the 
alternate path in order to survive with just a silver of health


21 Son of Grendel: Medium difficulty. Not much ammo and plenty troopers, but has a 2x charger. Using 
the speedrun strats can get you to the 2x charger pretty easily. Getting a no damage run on other 
hand is pure RNG grindfest. Aaron did the fastest no damage run of this map, where he was really 
fortunate that the enemies got frozen. I took a slower, but more easily doable approach of waking up 
as many enemies as I can (which included the ton of troopers in the big courtyard area). This 
improved the chance of enemies getting frozen and thus requiring less attempts to pull it off. I 
think this might be the 3rd hardest map in MI in general, though vastly behind Acme and Hang Brain.


22 Strange Aeons: Exposition style map. I guess it is alright for movement and platforming practice.


23 Bagged Again: Actually this is the hardest map in the game. So hard that I ran to the exit in 4 
seconds flat lol.


24 YTYBT: Easy map. Just make sure to use SMG instead of rockets to give the killing blow to 
fighters and hunters, since they don't drop circuit boards when they are gibbed and you need those 
to get to the secret area with ammo. The speedrun skip strategy makes it easy to do a no damage run. 


25 Aye Mak Sicur: Easy/medium-ish difficulty, until you insert the 2 circuit boards and activate the 3x 
charger, at which point it becomes very easy. The speedrun route is not only useful for doing a no 
damage run, but also for completing the map in general since you get the 3x charger unlocked early 
and also all the weapons in the secret exit terminal area.


28 Aie Mak Sicur: Easy/medium-ish difficuly. Actually slightly harder to clear than Aye Mak Sicur 
due to absence of health charger except for the one in the starting area where major juggernaut can 
respawn after you kill one. Speedrun route makes it easy to do a no damage run.


29 Carroll Street Station: Easy/medium-ish difficulty. Same as Aie, except in vaccuum so you won't 
be able to explore all of the map. Same-ish strategy for this map as Aie Mak Sicur.


30 You're Wormfood Dude: Another AMS variant. Again vaccuum. You are pretty much just meant to get 
out of there as soon as you can.


31 Try Again: I am not sure if this is harder or easier than the original M1 map. On one hand, there 
is only a 2x charger at the start instead of a 3x and the juggernauts are also much more durable to 
a point where you just don't have the ammo to kill all of them. But on the other hand, killing the 
juggernauts is not required and we just need to make sure there are no more than 8 enemies alive in 
order to leave. We also get proper weapons here instead of just having to rely on alien gun.


32 IIHARL: Easy/medium-ish difficulty. Probably slightly harder than the original M2 map, but not by 
much. Just as in the case of M2 version, the enemies seem like they spawn indefinitely, until they 
stop spawning. This makes it possible to eventually clean all the map. For the no damage run, I 
stick close to the switch the opens the first big door as this makes the troopers not come down. 
After the door starts rising again, stand on it and you can get to the high ground that allows you 
zip past the majority of the enemies with ease and reach the exit door.


33 YTYBT: Easy map. Same as regular YTYBT, except don't have to worry about hard killing/ gibbing 
enemies. The speedrun skip strategy makes it easy to do a no damage run. 
