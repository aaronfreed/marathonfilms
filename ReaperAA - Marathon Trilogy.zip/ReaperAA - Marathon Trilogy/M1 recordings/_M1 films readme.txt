Here are all the films of Marathon 1 on Total Carnage done using Aleph One 1.7.1


Notes/tips about the maps:


01 Arrival: Fairly easy as it is the first map. Good for building fighter fisting skills I suppose. 
Easy enough that I went with a no damage run.


02 Bigger Guns Nearby: Steps up the difficulty with a nasty ambush towards the end of the map, but 
otherwise mostly still easy. You get the first AR on this map. Also introduces the grenade jump 
secret and I suck at grenade jumping.


03 Never Burn Money: Still mostly pretty easy. More enemies now though and the introduction of wasps.


04 Defend This!: Another easy map. Went with the no damage run, which heightened the challenge.


05 Couch Fishing: The first tricky map of the game in my opinion. The starting will especially feel 
daunting and the rest of the map looks quite scary too. Luckily, there are some things that if you 
know can make the map easier:
1. The fighters ar the start can be cheesed by jumping from one ledge to the other, above the area 
which contains a compiler and 4 AR bullet clips.
2. You only need to hit one of the 3 panel switches to progress, so you don't need to deal with the 
trooper on the north-west side unless you are going for 100% kills. Even then, you can kill him 
later with AR.
3. The door leading to the areas with the high walkways can be kept open by pressing the button 
again when it is open.
4. The door which locks you in the very final area is a timed door and opens up after like 10 sec. 
Just slowly enter the area so that you are locked in there, but don't wake up the enemies.


06 The Rose: More like "The Doze", because this map is a heck of a slog and nothing more. Having to 
punch multiple Hulks is just not fun. An AR would've made this map much better.


07 Smells Like Napalm, Tastes Like Chicken: Easy map, unless you go for the fist only attempt like I 
did, which in that case would make it about medium difficulty. The key is to not get cornered in the 
maze by enemies. The most annoying part is the respawning wasps.


08 Cool Fusion: Medium-ish difficulty map. Would be categorized as easy if not for a couple of nasty 
traps. The hardest trap is the one involving the troopers + fighter ambush where I got lucky by 
having an enemy already trigger it without me having to drop down.


09 G4 Sunbathing: Medium difficulty map. The most threatening enemies on this map are not troopers 
but rather the compilers, mainly the cloaked versions. They can sneak up on you and surround you. 
That said, if you know the route and know how to get to the central oxygen and 2x charger, this is 
not hard to beat.


10 Blaspheme Quarantine: Another map with tons of Hulks. Given that this map doesn't require to kill 
all enemies, I definitely wasn't going to bother fisting any of those.


11 BOB-B-Q: Medium difficulty map. One needs patience rather than high skills to beat. Backtracking 
to the 2x charger is horrid and combined with the fact that I went for fist only run. The worst is 
having to fight 2 hunters blocking the exit terminal with fists. Just horrid.


12 Shake Before Use: Medium/High-ish difficulty map. Mainly because of the narrow bridge traps. The 
first bridge trap is particularly nasty. Even with the 3x charge, you simply cannot fight all those 
fighters and troopers head on. There is a trick though. As soon as you step into the airlock, the 
door behind you closes. To open it again, open the door facing you and step on the ledge and then 
quickly head back. Now enemies will be awake and they will start following you. I find that it is 
best to lure them in the room where you fought the 2 compilers, since you have enough room to move 
and dodge the troopers.

The 2nd bridge trap is one where the platform in the center rapidly decends and forces you to face 
troopers and fighters in a small area. The trick is to slowly step on the platform and then quicky 
back off so that the platform lowers but you don't. For the 3rd bridge, just lure all the enemies 
from there and fight them in the room before it.


13 Fire! Fire! Fire! Fire! Fire!: Medium difficulty map. Very rough RNG-ish start. Not too bad 
after that. Just make sure to conserve AR for the hard parts. Also polish up your grenade jumping 
skills for this one. Also did a bonus speedrun vid.


14 Colony Ship for Sale Cheap: Pretty easy map, unless you have problem solving the platforming 
puzzle. You have a 2x charger and decent amount of pistol and AR ammo. I didn't explore the crusher 
areas since I still remember getting softlocked there when I did my first casual walkthrough. Beat 
it on my 2nd attempt. 1st attempt ended not because I died, but because I screwed the puzzle and I 
decided to redo the attempt to make my run cleaner.


15 Habe Quiddan: Possibly the hardest map to vid in my opinion simply because we don't get any ammo 
on this map that we can use. Every single bullet is precious. This map's only saving grace is the 2 
2x chargers. If you can afford it, try to tank the damage from the "boom insects" instead of wasting 
bullets. Ofcourse that is when you can still access the first 2x charger.

Once you drop to the lava though you will have to wait for a long time before you get a hold of 
another charger, so make strategic use of your pistol. When you reach the "unstable bridge", stand 
at the edge and fire a bullet. This will lure the boom insects and then you can pistol them to 
death. Once you press the bridge switch, immediately dash to the other side, fire a bullet and then 
run back. This will lure enemies. Keep pressing the switch so that enemies try to come and then sink in lava. 

Once that is done, you will ultimately come across a big lava pit, with 4 blue fighters on the other 
side constantly firing at you, making it unsafe to get recharged from the 2x charger. Unless you 
saved atleast 2 clips, you likely won't be able to kill all of them anyway. I only had enough ammo 
to kill one of them, but luckily 2 other started infighting and got stuck. So only 1 of them was 
firing at me. Once you are able to use the 2x charger, you just need to keep your nerves calm and 
make sure to retreat to recharge, even if it means tedious backtracking :p


16 Neither High Nor Low: Medium difficulty map. Having to backtrack for the 2x charger is mildly 
annoying, but otherwise no issues here. Also did a bonus speedrun vid.


17 Pfhor Your Eye Only: Medium/High-ish difficulty map. The hard part is surviving till you get to 
the 2x charger. If you are luckly, the first enforcer will only take out about 50% of you health as 
you kill him with the pistol. After that make you way through the hallway while avoiding wasting 
alien gun pickups until you get to the 2x charger. If you managed to reach 2x charger, you have 
pretty much won, well as long as you have ammo for any enforcer that is.

That said, I decided to go for no charging run, since I saw Toon do it and I wanted to give that a 
shot. That makes this map quite harder, though this was still easier than the likes of Pfhoraphobia 
and especially Habe Quiddam. Whether going for no charging run or not, you absolutely want to get 
rid of enforcers first by going through the hallways, before clearing the rooms.


18 No Artificial Colors: Easy difficulty map. Only mildly tricky part is getting to the 3x charger.


19 Unpfhorgiven: Medium difficulty map. Getting to 2x charger is a bit annoying, but it is mostly 
easy after that. Just don't to the wasp area from the teleport, go from the otherside as you will be 
able to retreat to the 2x charger much more easily. Also enemies get stuck in this map a lot.


20 Two Times Two Equals: Medium difficulty map. Getting to 2x charger is not too hard and there are 
plenty of enforcers so ammo shouldn't be too much of a problem, if you are careful about picking up 
alien weapon.


21 Beware of Low Flying Defense Drones: The starting seems very RNG-ish. Sometimes, the tropper and 
Enforcer on the walkway would get stunlocked by the ally drones. Other times, they would easily kill 
them and then you too. Once you get through that though, your next task is to get to the 3x charger 
which you need to be a bit careful about. But once you get to the 3x charger, you have practically 
won. All about making sure to not pick up more alien weapon when you already have one.


22 Eupfhoria: Pretty hard map. Mostly because of that horrid start. Hunters with no space to move is 
just terrible. Once you manage to secure the 3x charger though, you have practically won. Fun fact, 
I was trying to go for all kills and I accidentally managed to exit before I got to do so.


23 Pfhoraphobia: Hard as heck. Not only is there no shield chargers, but ammo is also limited to 
Alien guns dropped from Enforcers. Make good use of the given ammo and if you can, try to make use 
of the fists.


24 Ain't Got Time Pfhor This: Medium difficulty map. Barely any ammo + good deal of enemies, notably 
troopers and wasps. Though the map is very short so a speedrunning style approach is very viable.


25 Welcome to the Revolution: Easy difficulty map. The hardest part is getting to the 3x charger. 
Done with that and you have won the map. Good for practicing fisting and herding skills.


26 Try Again: Medium difficulty map. The only problem you will have to face is having to manage your 
resources to kill the juggernauts. Otherwise, the 3x charger makes this one easy.


27 Ingue Ferroque: Medium/High-ish difficulty map. For 1st circular arena I hit the switches, aggro 
the troopers from one side and then retreat upstairs from other side. For the 2nd circular arena, go 
to the side with troopers and circlestrafe clockwise to make them kill each other and then deal with 
the fighters. Do this properly and you will hopefully have over 2x health when you get to the maze 
and thus not need to fight the trooper for the 2x charge. In the maze, wake up the enemies near the 
teleport and then retreat and wait for a few seconds. When the enemies go away, enter the center 
teleport. In the final circular arena, make sure to kill all the fighers without waking up the 
troopers. Then go anticlockwise and wake up the horde of troopers while also hitting the switch. 
Lure the troopers away from the south and go clockwise to the other side, hit the switch and dash 
into the lava pit for the exit.