Here are all the films of Marathon 2 on Total Carnage done using Aleph One 1.7 / 1.8

I think Marathon 2 is easier than M1 but harder than Infinity. As in the case of MI, I decided to 
challenge myself by trying to go for no damage/hit runs for as many maps as possible.

If we exclude The Big House, then there are total of 27 maps in the game and I have managed to beat 
20 of them with no hits:
- Waterloo Waterpark
- The Slings & Arrows of Outrageous Fortune
- Charon Doesn't Make Change
- What About Bob
- Come And Take your Medicine	(alternate route through water)
- We're Everywhere		(speed film)
- Nuke & Pave			(took lava damage, but otherwise no hit)
- Curiouser and Curiouser
- Eat It, Vid Boi		(I am very proud of this one)
- The Hard Stuff Rules		(speed film)
- If I Had A Rocket Launcher	(speed film)
- Sorry Don't Make It So	(speed film)
- For Carnage Apply Within	(speed film)
- This Side Towards Enemy
- God Will Sort The Dead
- My Own Private Thermopylae	(ignored the AR room)
- Kill Your Television
- Where The Twist Flops
- Beware of Abandoned Rental Trucks
- Fatum Iustum Stultorum

And following maps with no charging:
- Ex Cathedra
- Bob's Big Date
- Requiem for a Cyborg

Maps I haven't beaten with no hits or even no charging
- Six Thousand Feet Under	(bit hard. No charging is doable and has been done by Dr. Sumner)
- Begging For Mercy		(too hard and also mandatory lava damage for even no charging run)
- Feel The Noise		(bit hard. No charging is doable and has been done by Dr. Sumner)
- All Roads Lead to Sol		(too much mandatory lava damage for even no charging run)


Notes/tips about the maps:


01 Waterloo Waterpark: Fairly easy map which I managed to do a no damage run without much issue and 
also did it mostly fists only. Also got all secrets and the WSTE-M.


02 The Slings & Arrows of Outrageous Fortune: Memorizing the name of this map is harder for me than 
beating it without taking damage. Make sure to get the secret fusion pistol and you should be set.


03 Charon Doesn't Make Change: First map which gave me some trouble when trying to beat with no 
damage. Mainly it was the final room with lots of f'lickta and ticks which is slightly tricky to 
deal with.


04 What About Bob: Not a hard map. The hardest thing to do when going for no damage run is trying to 
keep your nerves since you need to play through the entire map and it is not a short one.


05 Come And Take your Medicine: Hard to beat if you are going for all kills/ammo, but easy if you 
just go for the objective. Taking the alternate speed route through water makes it easy to beat it 
without taking any damage.


06 We're Everywhere: Easy map all around. Speed route is easy to perform without taking any damage.


07 Ex Cathedra: First map of M2 I haven't managed to beat without damage. The final room is tricky 
to deal with due to being small, hard to leave and having troopers in it.


08 Nuke & Pave: A fairly tricky and RNG-ish start if going for a no damage run. I drop into lava to 
get to the other side. This is done so that I avoid some enemies and also so that I can go behind 
the troopers guarding the circuit wires and safely destroy them. Then I grab the invul and rush to 
the switch which leads to the exit terminal. I made the use of pistol shot to boost myself to reach 
that switch. If not going for speed route, you can make use of the 1x charger (which 3x charger in 
disguise) to wittle through the map.


09 Curiouser and Curiouser: A not too tricky map to beat with no damage. I make use of the slime 
pool to hide and get some troopers to kill each other. Otherwise, with decent amount of magnum ammo, 
you can kill enemies from a safe distance. When you get the shotgun, make sure to hit the 2 switches 
for the platforms before running out of ammo.


10 Eat It, Vid Boi: Probably the vid I am most proud of apart from my no damage Acme Station runs. 
Surprisingly, it didn't took me many attempts. Less than 8 infact. But I was not expecting that I 
would be able to get a no damage run until the part where I dealt tons of cyborgs before getting the 
fusion pistol. I don't have any particular strategy for this map other than just keep your distance 
from cyborgs and be good at doding the projectiles.


11 The Hard Stuff Rules: Fairly easy to beat with no damage. Make sure to grab the secret fusion so 
that you can deal with the cyborgs in the tight hallway. You only need to visit a certain polygon to 
enable the exit terminal.


12 Bob's Big Date: The final terminal room makes it very difficult to do a no damage run, but other 
than that, it is a fairly easy and straightforward map. You need to visit 2 polygons, before being 
able to exit from the final terminal. There is a 3x charger on this map as well so it is not a hard 
map.


13 Six Thousand Feet Under: Although possible for me to do it, it is a very hard map to beat with no 
charging and thus I decided to not do it. Dr. Sumner's no recharging vid is impressive and he was 
close to doing it no damage, but sadly got a single hit from a flickta. The part where you need to 
defeat cyborgs with lava is cool, but it requires enemies to cooperate and patiently wait for a tick 
to lower the platform with the lava switch. Making sure to not kill lava flickta during the initial 
parts reduce the chance of lava flickta respawning in the cyborg area. Also once you go past the 2x 
charger, there are some more cyborgs you have to deal. They can be dealt with by making sure the 
door remains open and then raising the lava again once the cyborgs are teleported in.


14 If I Had A Rocket Launcher: Easy/medium-ish difficulty. The enemies seem like they spawn 
indefinitely, until they stop spawning. This makes it possible to eventually clean all the map. 
For the no damage run, I stick close to the switch the opens the first big door as this makes the 
troopers not come down. After the door starts rising again, stand on it and you can get to the high 
ground that allows you zip past the majority of the enemies with ease and reach the exit door.


15 Sorry Don't Make It So: Rehash of Pfhor Your Eyes Only from M1. This map is very easy to beat 
with no hits (after some mandatory slime damage) if you go for the speed route. Easy/medium-ish 
difficulty map if played normally since there are many enemies and you mostly only have alien guns, 
but there is a 3x charger in this map.


16 For Carnage Apply Within: Speed route makes this very easy to beat with no damage. Otherwise, a 
very challenging map especially if you go for all ammo and all kills.


17 Begging For Mercy: Very hard map. One of the hardest few maps of the trilogy. No damage or even 
no charging is out of the question. Though the hardest part is definitely the start before getting 
to the 3x charger. Once you get to the charger, it is mainly about keeping your nerves calm.


18 The Big House: Oh no!!! I am trapped. Anyway, just wait until you get rescued. Or try to punch 
enemies and make them hurt each other so that less Bobs die.


19 This Side Towards Enemy: Fairly easy map. No damage run involves using the dual magnums to take 
out enemies such as troopers, flickta and compilers from a safe distance.


20 God Will Sort The Dead: Easy/medium-ish difficulty. Hardest part is the "basement room" due to 
many enemies there. I make sure to kill the 2 brown shirt Bobs to make room for when the hunters 
spawn from behind on the stairs. Also I make sure to not trigger the trooper ambush there.


21 My Own Private Thermopylae: A not so hard map to beat with no damage. With long range magnum 
sniping, exploiting water to get enemies to kill themselves and avoiding the AR room because of the 
nasty trap there, I got it in less than 6 attempts I think.


22 Kill Your Television: Easy map. You get plenty of fusion ammo to deal with any cyborgs and also 
flamethrower too. Only tricky part is making sure to not get hit by cyborgs grenades with fighting 
on the ledges.


23 Where The Twist Flops: My strategy for this map is to make sure to get another magnum from a dead 
Bob, get the secret invul and rush to the room with the 2x charger. I do this because the 2x charger 
room has tons of hunters, which are hard to kill with no damage without invul. The room is also a 
good retreat point once you clear the initial hunters. After that, it is a matter of gradually 
defeating the enemies and making use of weapons if things get hairy.


24 Beware of Abandoned Rental Trucks: The starting of the map is tricky if going for a no damage run.
Otherwise, the secret ammo treasure underwater means that ammo is never an issue and if you play 
carefully, you shouldn't have much issue. Note that I skipped the multi cyborg trap near the final 
terminal by going around the edges.


25 Requiem for a Cyborg: Some RNG factors involved made it really hard for me to do a no damage run. 
I spent a great deal of attempts trying to get a no damage run on this map, but ultimately settled 
with a no charging run instead. You don't get any ammo on this map besides the 3 alien guns and 
there are a good deal of troopers on this map.


26 Fatum Iustum Stultorum: Fairly easy map. Map is played in regular manner and the secret ammo 
treasure means that ammo is never an issue.


27 Feel The Noise: Although possible for me to do it, it is a very hard map to beat with no charging 
and thus I decided to not do it. Once possible way to make a no charging run, or even just a plain 
vid easier would be to immediately trigger and spawn as many enemies as possible in order to get 
them to freeze. This makes it easier to get through the eariler areas, but it makes a certain room 
with hunters and a platform trickier, since the hunters become harder to circlestrafe when they keep 
getting frozen and unfrozen randomly. Also in my vid, I cheesed the final part by triggering the 
enemies from the top ledge. But to make up, I did the rest of the map without freezing enemies and 
with fist only.


28 All Roads Lead to Sol: Easy/medium-ish difficulty map, which is mostly quite easy and is just a 
matter of taking potshots at the juggernauts until they die. Only the final room is somewhat tricky.
No damage or even no charging run is out of the question though because of the nature of the map.