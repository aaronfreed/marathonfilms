Triggers = {
	init = function(restoring)
		Game.proper_item_accounting = true
		if Game.ticks == 0 and (
			(
				(Level.map_checksum == 160446416 or Level.map_checksum == 3650697747) and -- Rubicon and Rubicon X maps
				(Level.index == 5 or Level.index == 13 or Level.index == 38 or Level.index == 60 or Level.index == 68)
			) or (
				Level.map_checksum == 2856322626 and (
					Level.index == 2 or Level.index == 4 or Level.index == 6 or Level.index == 12 or
					Level.index == 16 or Level.index == 18 or Level.index == 20 or Level.index == 27 or Level.index == 35
				)  -- original Tempus Irae map
			) or (
				Level.map_checksum == 3544251807 and Level.index == 8  -- Marathon EVIL
			) or (
				Level.map_checksum == 2754604234 and (
					Level.index == 2 or Level.index == 9
				) -- Pfh'Joueur
			)
		)
		then
			Players[0].items["uplink chip"] = 1
		end
	end
}