Films of Megiddo Game on Total Carnage done using Aleph One 1.8.1


Notes/tips about the maps:


02 Mister Print - Where's Tony?: The first map is surprisingly the hardest map of the scenario with 
plenty of surprise trooper ambushes in tight spaces. Quite fun office map and for some reason feels 
Duke Nukem 3D-ish in terms of level design philosophy. Having foreknowledge greatly helps here.


03 Armageddon: Really easy map despite being in vacuum. Plenty of chargers, even 3x chargers and 
also powerups. During my casual walkthrough, I got stuck because I goofed up on not noticing a 
switch which prevented my progress. Otherwise an alright map.


03 Payback's A Bitch: Another really easy map. Again 3x chargers are in abundance and so is ammo. 
Plenty of juggernauts to see, but almost all of them get destroyed by the S'pht defenders and you 
don't need to use much ammo. The design of this map feels a bit like Tempus Irae, which should be 
obvious why.
