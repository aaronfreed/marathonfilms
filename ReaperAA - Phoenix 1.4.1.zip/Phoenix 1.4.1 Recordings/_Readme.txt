Films of all Phoenix 1.4.1 maps (atleast all the non-exposition ones) on Total Carnage done using Aleph One 1.6.2

Got all the secrets and kills as well on almost all maps. Except on Neo New Mordor, Escape 2000 and Holy Wars, where I missed like a couple of enemies on each.

Also did some maps with added challenge of no damage taken or no shield recharge use rules.

Most of the maps were not too hard to beat but some definitely were quite challenging. Top 6 hardest maps for me to beat were:
- Another Dimensions (easily the hardest one for me)
- Holy Wars
- Neo New Mordor
- Exercise in Excess
- The Face of Modern Gaming
- Shades of Gray

Other somewhat challenging ones for me (in no particular order) were:
- Roquefortress
- Tantive IV (normally quite easy, but was challenging with no shield recharge rule)
- Escape 2000
- Alexandretta (very easy normally, but no damage run was kind of challenging)
- Running from Evil (same case as Alexandretta, though was lucky that I pulled it off in my 2nd attempt)
- Vampire Killer (still surprised that I managed to beat that map on my 1st attempt and mostly blind too, except towards near the end where used RyokoTK's YT video to find secrets)
- Intervals (playing aggressive/speedrunner style actually makes this easier in my opinion)

My favorites to vid:
- S'phtstorm (really fun to run around using invul/regeneration and get about 2/3rd of the enemies killed in first 2 minutes)
- Intervals (similar to S'phtstorm. Also we have Katar for this)
- Red Eye Express (another one I really liked to vid)
- Roquefortress (because it's a great map)