Here are all the films of Kill Them All IV 1.0 on Total Carnage done using Aleph One 1.8.1

While there are a few vids in here which are regular playthroughs or even no damage vids, the vast 
majority of these vids are speedrun style.

The highlights for me in KTA are:
- 10: Power Word Kill		(RL power fantasy)
- 20: Babylon Basics		(I like that you can choose 2 different routes to start from)
- 22: Guerilla Radio		(very cool to speedrun, especially the start jumps with SMG boost)
- 36: The Scythe		(The Doom megawad reference is not lost on me)
- 45: San Sebastian		(BS start, but fun to vid nonetheless)



Notes/tips about some of the maps:


05 Souvlaki: For some reason, I really don't know how to get to the secret SPNKR and the 3x can. I 
would appreciate if someone showed me how to get those, assuming it is possible to get those.


08 Champagne Bath: Tricky map to beat without taking any damage. I like how the name refers to 
giving our enemies a lava bath.


10 Power Word Kill: Probably my favorite map of the scenario. I really loved the chain explosion of 
30-something hunters towards the end. Could've saved a few seconds at the end by rocket jumping from 
2x charger area to the final door, but no biggie.


13 Guns of Avalon: A surprisingly low resource thriller among the sea of high octane action maps. 
In my speedrun, I made a slight goof by healing myself, right before grabbing the 2x can.


15 King of The Mountain: Notice how I avoided picking up the 2x can at the start. Not easy to get 
through the pillar on right side as it seems to require a precise angle and momentum.


18 Poppy Seed: The door camping in this map is ridiculous. And probably not even much slower either, 
since hunter chain reaction can quickly kill the enemy waves.


19 The limacon: Very cool concept map. I think Hellpak's map Stairway To Aaron is a cooler map with 
an almost similar concept, but this is still a pretty cool little map.


21 It's us two against the mafia: I really don't know what makes the final hunters and enforer at 
the exit door spawn. Is it the platform with the SPNKR? Don't know.


32 Bola Soup: The trap with the 2x can and tons of troopers is very nasty and killed me many times. 
Thus I cheezed the final fight since I didn't wanted to die there. I think there is definitely room 
for optimization.


35 Polygons, Platforms and Duct Tape: One of the few maps where I didn't just copy Dis/Cassis' strat 
and instead came up with my own strategy to beat their record. Though I did make mistakes in my run, 
but just getting through the start is hard.


40 Neptunia: A small tip for speedrunning. When rushing on the path beyond the platform for the 3x
and button, use the alien gun instead of SMG, since you have a better chance of pushing through the 
teleporting enemies.


42 Dancing lights: For some reason, I got softlocked when I was practicing the map on kindergarten 
as some enemy closet doors didn't open. Thankfully didn't happen in my TC run. Also my longest vid 
of this pack since I really don't know how you can meaningfully optimize it for speedrun.


49 the upwards march: Made a few slight mistakes here and there, but also got really lucky with with 
RL hits and infighting. Surprised myself with my final time.


52 treason trigger: You might notice that near the end when I get up the lift, I stopped awkwardly
for a couple of seconds. My mouse got stuck for some reason. I tried to vid again because of that, 
but was not able to get a sub-2:00 run again, so I just let it slide.


53 The Final Sacrifice: Getting through the 3 troopers guarding the lift is tricky. I found more 
success by firing fusion at them and waiting for them to come out before rushing to the lift. I lost 
a few seconds from the lift which activates after inserting the chip, but otherwise a solid run.

