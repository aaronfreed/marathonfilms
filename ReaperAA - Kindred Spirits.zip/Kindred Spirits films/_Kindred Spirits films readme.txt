Here are all the films of Kindred Spirits on Total Carnage done using Aleph One 1.7.0

Got all the secrets (and probably all kills too) on all maps.

Athough not as hard as the hardest map of Phoenix (Another Dimensions), the last 2 maps were still 
generally on par with some of the harder Phoenix maps.


Notes about the last 2 maps:

Dr. Tycho's Castle: Fairly tricky starting moments. The most egregious moment is having to go dive 
into lava to hopefully get on the moving platform and then deal with fighters on ledge in order to 
get access the 2x charger. Yes you don't HAVE to do it, but on TC you will definitely need it. Other 
than that, it is mostly about playing slow and steady. The cyborgs and the inescapable lava pits are 
your worst enemies on this map. I prefer to clear the north east side of the map first in order to 
get access to another 2x charger (which is easier to backtrack to) and also obtain the secret napalm 
launcher. The napalm is especially great at stunlocking the cyborgs which is very handy, especially 
when you do the platforming on the south-west side and then have to face 2 cyborgs in a small room.

When The Water Breaks: General theme of the map is to play cautiously, know you escape route and 
try to conserve your powerful weapons such as rockets, WSTE-M and napalm for more hairy situations. 
Again, cyborgs are the most annoying enemies and napalm is great at stunlocking them. If you follow 
the above rules, you should mostly be fine up until the final fight. By this point, you should have 
enough shotgun ammo hopefully, so don't be afraid to use them. I could've handled the final fight 
better but things worked out in the end. I think the best way for final fight is:
- Rocket (or SMG) the first group of fighters in the door
- Napalm the first cyborg
- Shotgun the incoming troopers
- Fusion (or rocket if you have enough) the group of Hunters
- Rocket the group of cyborgs firing from high ground
- Switch to shotguns and continue circle strafing to hold ground until backtracking portal is open
- Backtrack and 3x charge yourself to finish off the remaining foes

Once done with that, make sure to not miss the last secret near the exit teleporter.
