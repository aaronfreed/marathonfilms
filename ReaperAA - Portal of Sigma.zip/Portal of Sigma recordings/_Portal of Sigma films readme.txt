Here are all the films of Portal of Sigma on Total Carnage done using Aleph One 1.9.0

Portal of Sigma is a controversial scenario. Since the author abandoned the scenario and rage quit 
from the marathon scene, this scenario is not much talked about and no one had vidded it up until 
now.

Still, despite its incomplete state, all the maps present (excecpt Suenagaku) in this scenario are 
pretty much complete and are beatable from start to end. Suenagaku is the only really unfinished map 
here.

Also, while "07 - All good people are asleep and dreaming" and "08 - One mint julip" are complete 
from a level design point, they seem to not have the physics file attached, which makes the physics 
janky. I used atque to split the maps and add the physics file to them. I recorded films of those 
two maps with the fixed map file while the rest of the films are recorded with the original map file 
from 2006. I also fixed few spelling mistakes (but likely not all mistakes) in the updated map file.



Notes/tips about some of the maps:


04 Destination H.E.L.L.: If you have played the old Apotheosis Beta, you will recognize this map. 
This is in Apotheosis Beta named as "4 dead Otters on string dancing". Thankfully, this version of 
the map is not in vaccuum. But it might still be the 2nd hardest map of the scenario due to tight 
ammo, especially in the first half.


06 Todo lo que queda: Probably the most spacious map. Has some nice looking parts, but it could've 
had more enemies and action.


07 All good people are asleep and dreaming: There is one softlock I noticed in this map. At the part 
where you are at the narrow ledge, which lowers to the cyborg ambush. If you jump down from there 
before the ledge starts moving down, you are trapped and cannot go back up.


10 Suenagaku: Obviously incomplete. Every terminal shows the same message and allows you to exit the 
map. The layout seems to be like 90% complete? Don't know, but the enemy/item placement is definite 
not. Still, I did kill every enemy I saw and collected every ammo I could find in my film.


11 Dream a prophecy, live a legend: The secret vidmaster map is likely the hardest map of this 
scenario. Ammo and health is tight, but nothing a decent vid player can't handle. If you make good 
usage of infighting and fists in the first half, the rest of the map becomes much easier. Also, it 
is a very nice looking map, as are all the other spaceship maps in the scenario.